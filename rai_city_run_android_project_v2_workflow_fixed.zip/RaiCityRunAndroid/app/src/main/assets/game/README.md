# Rai City Run v1.0.0

Original mobile-first endless runner game built with HTML5 Canvas, CSS and JavaScript.

## Run locally
Open `index.html`, or use a local server for full PWA support:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

## Controls
- Swipe left/right: change lane
- Swipe up: jump
- Swipe down: slide
- Keyboard: arrow keys

## Ads
The current rewarded-ad flow uses a demo loading simulation. Replace `showRewardedAd()` in `game.js` with callbacks from an approved HTML5 game ad provider. Do not use ordinary AdSense display ads as forced game interstitials.

## Originality
All visuals are drawn procedurally in Canvas. No Subway Surfers artwork, characters, branding, music or code is included.
