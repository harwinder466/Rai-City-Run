'use strict';

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const $ = (id) => document.getElementById(id);

const ui = {
  start: $('startScreen'), over: $('gameOverScreen'), help: $('helpScreen'), hud: $('hud'),
  score: $('scoreText'), coins: $('coinText'), best: $('bestText'), menuBest: $('menuBest'), menuCoins: $('menuCoins'),
  finalScore: $('finalScore'), finalCoins: $('finalCoins'), finalBest: $('finalBest'), revive: $('reviveBtn'),
  adStatus: $('adStatus'), loading: $('loading'), toast: $('toast'), sound: $('soundBtn')
};

const store = {
  get best() { return Number(localStorage.getItem('rai-run-best') || 0); },
  set best(v) { localStorage.setItem('rai-run-best', String(v)); },
  get coins() { return Number(localStorage.getItem('rai-run-coins') || 0); },
  set coins(v) { localStorage.setItem('rai-run-coins', String(v)); },
  get sound() { return localStorage.getItem('rai-run-sound') !== 'off'; },
  set sound(v) { localStorage.setItem('rai-run-sound', v ? 'on' : 'off'); }
};

let gameOverCount = Number(localStorage.getItem('rai-run-gameovers') || 0);

const game = {
  running: false, paused: false, lane: 1, y: 0, vy: 0, sliding: false, slideTimer: 0,
  speed: 8, distance: 0, score: 0, runCoins: 0, revived: false,
  obstacles: [], coinItems: [], particles: [], lastSpawn: 0, lastCoinSpawn: 0, lastTime: 0,
  roadOffset: 0, skylineOffset: 0
};

let W = 0, H = 0, DPR = 1, audioCtx = null;
const lanes = [-1, 0, 1];

function resize() {
  const rect = canvas.getBoundingClientRect();
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  W = Math.max(320, rect.width); H = Math.max(420, rect.height);
  canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
}
window.addEventListener('resize', resize);

function laneX(lane, depth = 1) {
  const spread = W * (0.22 + depth * 0.09);
  return W / 2 + (lane - 1) * spread;
}

function show(panel) {
  [ui.start, ui.over, ui.help].forEach(p => p.classList.remove('visible'));
  if (panel) panel.classList.add('visible');
}

function updateMenu() {
  ui.menuBest.textContent = store.best;
  ui.menuCoins.textContent = store.coins;
  ui.best.textContent = store.best;
  ui.sound.textContent = store.sound ? '🔊' : '🔇';
}

function toast(message) {
  ui.toast.textContent = message;
  ui.toast.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => ui.toast.classList.remove('show'), 1400);
}

function beep(freq = 440, duration = .06) {
  if (!store.sound) return;
  try {
    audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator(); const gain = audioCtx.createGain();
    osc.frequency.value = freq; gain.gain.value = .035;
    osc.connect(gain); gain.connect(audioCtx.destination); osc.start();
    gain.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime + duration);
    osc.stop(audioCtx.currentTime + duration);
  } catch (_) {}
}

function startGame() {
  Object.assign(game, { running:true, paused:false, lane:1, y:0, vy:0, sliding:false, slideTimer:0,
    speed:8, distance:0, score:0, runCoins:0, revived:false, obstacles:[], coinItems:[], particles:[],
    lastSpawn:0, lastCoinSpawn:0, lastTime:performance.now(), roadOffset:0 });
  show(null); ui.hud.classList.remove('hidden'); ui.revive.classList.remove('hidden'); ui.adStatus.textContent='';
  requestAnimationFrame(loop);
}

function endGame() {
  game.running = false;
  const best = Math.max(store.best, game.score);
  store.best = best; store.coins = store.coins + game.runCoins;
  ui.finalScore.textContent = game.score; ui.finalCoins.textContent = game.runCoins; ui.finalBest.textContent = best;
  ui.hud.classList.add('hidden'); show(ui.over); updateMenu(); beep(120, .25);
  gameOverCount += 1; localStorage.setItem('rai-run-gameovers', String(gameOverCount));
  // Show an interstitial only at a natural break, every second game over.
  if (gameOverCount % 2 === 0 && window.AndroidAds?.showInterstitial) {
    try { window.AndroidAds.showInterstitial(); } catch (_) {}
  }
}

function completeRevive() {
  ui.loading.classList.add('hidden');
  game.revived = true; game.running = true; game.paused = false; game.obstacles = []; game.y = 0; game.vy = 0;
  ui.revive.classList.add('hidden'); show(null); ui.hud.classList.remove('hidden');
  game.lastTime = performance.now(); toast('Revived!'); requestAnimationFrame(loop);
}

window.onRewardedAdResult = function (earned) {
  if (earned) completeRevive();
  else { ui.loading.classList.add('hidden'); ui.adStatus.textContent = 'Ad unavailable. Try again.'; }
};

async function showRewardedAd() {
  if (game.revived) return;
  ui.loading.classList.remove('hidden'); ui.adStatus.textContent='';
  if (window.AndroidAds?.showRewarded) {
    try { window.AndroidAds.showRewarded(); return; } catch (_) {}
  }
  // Browser fallback for development preview only.
  await new Promise(resolve => setTimeout(resolve, 1200));
  completeRevive();
}

function moveLane(dir) { if (!game.running) return; game.lane = Math.max(0, Math.min(2, game.lane + dir)); beep(300, .03); }
function jump() { if (!game.running || game.y > 0 || game.sliding) return; game.vy = 19; beep(520, .05); }
function slide() { if (!game.running || game.y > 0) return; game.sliding = true; game.slideTimer = 0.75; beep(240, .04); }

function spawnObstacle() {
  const types = ['barrier','crate','sign'];
  const type = types[Math.floor(Math.random()*types.length)];
  game.obstacles.push({ lane:Math.floor(Math.random()*3), z:1.12, type, hit:false });
}
function spawnCoins() {
  const lane = Math.floor(Math.random()*3); const count = 4 + Math.floor(Math.random()*4);
  for (let i=0;i<count;i++) game.coinItems.push({ lane, z:1.05+i*.08, taken:false, bob:Math.random()*Math.PI*2 });
}

function update(dt) {
  game.speed = Math.min(20, 8 + game.distance / 900);
  game.distance += game.speed * dt * 10; game.score = Math.floor(game.distance);
  game.roadOffset = (game.roadOffset + game.speed * dt * 70) % 90;
  if (game.vy !== 0 || game.y > 0) { game.y += game.vy * dt; game.vy -= 40 * dt; if (game.y <= 0) { game.y = 0; game.vy = 0; } }
  if (game.sliding) { game.slideTimer -= dt; if (game.slideTimer <= 0) game.sliding = false; }

  game.lastSpawn += dt; game.lastCoinSpawn += dt;
  if (game.lastSpawn > Math.max(.65, 1.25 - game.speed*.025)) { spawnObstacle(); game.lastSpawn = 0; }
  if (game.lastCoinSpawn > 1.15) { spawnCoins(); game.lastCoinSpawn = 0; }

  const dz = dt * game.speed * .11;
  for (const o of game.obstacles) {
    o.z -= dz;
    if (!o.hit && o.z < .13 && o.z > -.04 && o.lane === game.lane) {
      const safe = (o.type === 'barrier' || o.type === 'crate') ? game.y > 1.2 : game.sliding;
      if (!safe) { o.hit = true; endGame(); return; }
    }
  }
  for (const c of game.coinItems) {
    c.z -= dz; c.bob += dt*6;
    if (!c.taken && c.z < .14 && c.z > -.05 && c.lane === game.lane && game.y < 3.2) {
      c.taken = true; game.runCoins++; beep(760, .04); burst(laneX(game.lane), H*.73 - game.y*11);
    }
  }
  game.obstacles = game.obstacles.filter(o=>o.z>-.15); game.coinItems = game.coinItems.filter(c=>c.z>-.15&&!c.taken);
  for (const p of game.particles) { p.x += p.vx*dt; p.y += p.vy*dt; p.life -= dt; }
  game.particles = game.particles.filter(p=>p.life>0);
  ui.score.textContent = game.score; ui.coins.textContent = game.runCoins;
}

function burst(x,y) { for(let i=0;i<8;i++) game.particles.push({x,y,vx:(Math.random()-.5)*100,vy:(Math.random()-.5)*100,life:.45}); }

function drawBackground() {
  const sky = ctx.createLinearGradient(0,0,0,H); sky.addColorStop(0,'#162447'); sky.addColorStop(.55,'#25345e'); sky.addColorStop(1,'#0c101d');
  ctx.fillStyle=sky; ctx.fillRect(0,0,W,H);
  ctx.fillStyle='#ffd166'; ctx.beginPath(); ctx.arc(W*.78,H*.16,30,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#1a2543';
  for(let i=0;i<12;i++){ const bw=40+(i%3)*18; const bh=70+(i*37)%150; const x=(i*83+game.skylineOffset)% (W+100)-50; ctx.fillRect(x,H*.42-bh,bw,bh); }
  game.skylineOffset = (game.skylineOffset - .08) % (W+100);
  // road perspective
  ctx.fillStyle='#141923'; ctx.beginPath(); ctx.moveTo(W*.42,H*.36); ctx.lineTo(W*.58,H*.36); ctx.lineTo(W*.95,H); ctx.lineTo(W*.05,H); ctx.closePath(); ctx.fill();
  ctx.strokeStyle='rgba(255,255,255,.28)'; ctx.lineWidth=3;
  for(const f of [-1/3,1/3]){ ctx.beginPath(); ctx.moveTo(W/2+f*W*.09,H*.36); ctx.lineTo(W/2+f*W*.82,H); ctx.stroke(); }
  ctx.strokeStyle='rgba(247,201,72,.55)'; ctx.lineWidth=4;
  for(let y=H*.39-game.roadOffset;y<H;y+=90){ const t=(y-H*.36)/(H*.64); const x1=W/2-W*.44*t, x2=W/2+W*.44*t; ctx.beginPath(); ctx.moveTo(x1,y); ctx.lineTo(x2,y); ctx.stroke(); }
}

function project(lane,z) {
  const t = 1 - z; const y = H*.36 + t*t*H*.64; const spread = W*(.07+t*.26);
  return { x:W/2+(lane-1)*spread, y, s:.25+t*1.05 };
}

function drawObjects() {
  const all=[...game.obstacles.map(o=>({...o,kind:'o'})),...game.coinItems.map(c=>({...c,kind:'c'}))].sort((a,b)=>b.z-a.z);
  for(const item of all){ if(item.z<0||item.z>1.2)continue; const p=project(item.lane,item.z);
    if(item.kind==='c'){
      const r=10*p.s; ctx.fillStyle='#f7c948'; ctx.beginPath(); ctx.ellipse(p.x,p.y+Math.sin(item.bob)*4,r*.7,r,0,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#7a5200'; ctx.font=`${Math.max(8,10*p.s)}px sans-serif`; ctx.textAlign='center'; ctx.fillText('R',p.x,p.y+4);
    } else {
      if(item.type==='sign'){
        ctx.fillStyle='#ff5d73'; ctx.fillRect(p.x-35*p.s,p.y-90*p.s,70*p.s,24*p.s); ctx.fillStyle='#d6dbe7'; ctx.fillRect(p.x-28*p.s,p.y-66*p.s,6*p.s,66*p.s); ctx.fillRect(p.x+22*p.s,p.y-66*p.s,6*p.s,66*p.s);
      } else {
        ctx.fillStyle=item.type==='crate'?'#a66a2c':'#ff7b00'; ctx.fillRect(p.x-30*p.s,p.y-42*p.s,60*p.s,42*p.s);
        ctx.strokeStyle='#3b250f'; ctx.lineWidth=3*p.s; ctx.strokeRect(p.x-30*p.s,p.y-42*p.s,60*p.s,42*p.s);
      }
    }
  }
}

function drawPlayer() {
  const x=laneX(game.lane), ground=H*.79-game.y*13, scale=Math.min(1.15,W/430);
  ctx.save(); ctx.translate(x,ground); ctx.scale(scale,scale);
  if(game.sliding){ ctx.rotate(-.18); ctx.translate(0,18); }
  ctx.fillStyle='rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(0,31,26,8,0,0,Math.PI*2); ctx.fill();
  ctx.strokeStyle='#f7c948'; ctx.lineWidth=9; ctx.lineCap='round';
  const legSwing=Math.sin(game.distance*.13)*9;
  ctx.beginPath(); ctx.moveTo(-7,10); ctx.lineTo(-12+legSwing,34); ctx.moveTo(7,10); ctx.lineTo(12-legSwing,34); ctx.stroke();
  ctx.strokeStyle='#59a5ff'; ctx.lineWidth=12; ctx.beginPath(); ctx.moveTo(0,-28); ctx.lineTo(0,12); ctx.stroke();
  ctx.strokeStyle='#f2b38f'; ctx.lineWidth=8; ctx.beginPath(); ctx.moveTo(-4,-18); ctx.lineTo(-19-legSwing*.4,3); ctx.moveTo(4,-18); ctx.lineTo(19+legSwing*.4,3); ctx.stroke();
  ctx.fillStyle='#f2b38f'; ctx.beginPath(); ctx.arc(0,-43,13,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#121826'; ctx.beginPath(); ctx.arc(0,-48,13,Math.PI,Math.PI*2); ctx.fill();
  ctx.restore();
  for(const p of game.particles){ ctx.globalAlpha=Math.max(0,p.life/.45); ctx.fillStyle='#f7c948'; ctx.fillRect(p.x,p.y,4,4); } ctx.globalAlpha=1;
}

function render() { drawBackground(); drawObjects(); drawPlayer(); }
function loop(now) {
  if(!game.running) return;
  const dt=Math.min(.034,(now-game.lastTime)/1000||0); game.lastTime=now;
  update(dt); render(); if(game.running) requestAnimationFrame(loop);
}

let sx=0,sy=0;
canvas.addEventListener('pointerdown',e=>{sx=e.clientX;sy=e.clientY;canvas.setPointerCapture(e.pointerId);});
canvas.addEventListener('pointerup',e=>{const dx=e.clientX-sx,dy=e.clientY-sy;if(Math.max(Math.abs(dx),Math.abs(dy))<22)return;if(Math.abs(dx)>Math.abs(dy))moveLane(dx>0?1:-1);else dy<0?jump():slide();});
window.addEventListener('keydown',e=>{ if(e.key==='ArrowLeft')moveLane(-1); if(e.key==='ArrowRight')moveLane(1); if(e.key==='ArrowUp'||e.key===' ')jump(); if(e.key==='ArrowDown')slide(); });

$('playBtn').addEventListener('click',startGame);
$('restartBtn').addEventListener('click',startGame);
$('homeBtn').addEventListener('click',()=>{show(ui.start);updateMenu();});
$('howBtn').addEventListener('click',()=>show(ui.help));
$('closeHelpBtn').addEventListener('click',()=>show(ui.start));
$('reviveBtn').addEventListener('click',showRewardedAd);
ui.sound.addEventListener('click',()=>{store.sound=!store.sound;updateMenu();toast(store.sound?'Sound on':'Sound off');});
document.addEventListener('visibilitychange',()=>{ if(document.hidden&&game.running){ game.paused=true; game.running=false; toast('Game paused'); } else if(game.paused){ game.paused=false; game.running=true; game.lastTime=performance.now(); requestAnimationFrame(loop); } });

resize(); updateMenu(); render();
