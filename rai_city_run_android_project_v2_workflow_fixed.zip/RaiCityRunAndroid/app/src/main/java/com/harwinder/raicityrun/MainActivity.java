package com.harwinder.raicityrun;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity {
    private static final String TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
    private static final String TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917";
    private WebView webView;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidAdsBridge(), "AndroidAds");

        MobileAds.initialize(this, status -> {
            loadInterstitial();
            loadRewarded();
        });
        webView.loadUrl("file:///android_asset/game/index.html");
    }

    private void loadInterstitial() {
        InterstitialAd.load(this, TEST_INTERSTITIAL, new AdRequest.Builder().build(),
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) {
                    interstitialAd = ad;
                    ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override public void onAdDismissedFullScreenContent() { interstitialAd = null; loadInterstitial(); }
                        @Override public void onAdFailedToShowFullScreenContent(AdError error) { interstitialAd = null; loadInterstitial(); }
                    });
                }
                @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
            });
    }

    private void loadRewarded() {
        RewardedAd.load(this, TEST_REWARDED, new AdRequest.Builder().build(),
            new RewardedAdLoadCallback() {
                @Override public void onAdLoaded(RewardedAd ad) {
                    rewardedAd = ad;
                    ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override public void onAdDismissedFullScreenContent() { rewardedAd = null; loadRewarded(); }
                        @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                            rewardedAd = null; sendReward(false); loadRewarded();
                        }
                    });
                }
                @Override public void onAdFailedToLoad(LoadAdError error) { rewardedAd = null; }
            });
    }

    private void sendReward(boolean earned) {
        webView.post(() -> webView.evaluateJavascript("window.onRewardedAdResult(" + earned + ")", null));
    }

    public final class AndroidAdsBridge {
        @JavascriptInterface public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitialAd != null) interstitialAd.show(MainActivity.this);
                else loadInterstitial();
            });
        }
        @JavascriptInterface public void showRewarded() {
            runOnUiThread(() -> {
                if (rewardedAd != null) {
                    rewardedAd.show(MainActivity.this, item -> sendReward(true));
                } else {
                    Toast.makeText(MainActivity.this, "Ad is loading. Try again.", Toast.LENGTH_SHORT).show();
                    sendReward(false); loadRewarded();
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidAds"); webView.destroy(); }
        super.onDestroy();
    }
}
